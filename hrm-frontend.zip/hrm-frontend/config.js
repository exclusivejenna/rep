'use strict';
const dotenv = require('dotenv');
const path = require('path');
const assert = require('assert');

console.log('Loaded Environment Variables:', process.env); // Add this line

// Load environment variables
dotenv.config();

// Extract environment variables
const {
  PORT,
  HOST,
  HOST_URL,
  DB_DATABASE,
  DB_SERVER,
  DB_ENCRYPT,
} = process.env;

const sqlEncrypt = DB_ENCRYPT === 'true'; // Align with DB_ENCRYPT

// Validate mandatory variables
assert(PORT, 'Port is required');
assert(HOST, 'Host is required');

module.exports = {
  port: PORT,
  host: HOST,
  url: HOST_URL, // Corrected from URL to HOST_URL
  sql: {
    server: DB_SERVER,
    database: DB_DATABASE, // Fixed typo
    options: {
      encrypt: sqlEncrypt, // Corrected to use DB_ENCRYPT
      enableArithAbort: true,
    },
  },
};
